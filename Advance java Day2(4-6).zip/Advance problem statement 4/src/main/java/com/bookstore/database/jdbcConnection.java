package com.bookstore.database;



	import java.sql.Connection;
	import java.sql.DriverManager;
	import java.sql.SQLException;

	public class jdbcConnection  {

		private static Connection connection;
		
		public jdbcConnection(String driver,String url,String user,String pwd) throws ClassNotFoundException,SQLException
		{	
			Class.forName(driver);
			this.connection= DriverManager.getConnection(url,user,pwd);
		}

		public static Connection getConnection() {
			return connection;
		}
		
		public void closeConnection() throws SQLException
		{
			this.connection.close();
		}
	}
