package com.problemstmt1;
import java.util.Scanner;
public class EvenNumbers {
public static void main(String[] args) {
	
	int n ;
	System.out.println("Enter the value of n");
	Scanner sc=new Scanner(System.in);
	 n=sc.nextInt();
	for(int i=0;i<=n;i=i+2) {
		if(i%2==0){
		System.out.println("The numbers are as follows "+i);
	}
}
}
}