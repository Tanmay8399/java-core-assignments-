package com.tanmay;

public class Expression {

	

		public static void main(String[] args) {
			
		
		String txt= (" 23  +  45  -  (  343  /  12  ) ");
		String[] t=txt.split("\\s");
		
		for(String t1:t){  
			System.out.println(t1); 
			//System.out.println(" ");
		}
	}

	}