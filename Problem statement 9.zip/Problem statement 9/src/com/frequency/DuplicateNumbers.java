package com.frequency;
import java.util.HashMap;
	import java.util.Map;
	 
	public class DuplicateNumbers {
	
	  public static void findFrequency(int[] nums, int left, int right,Map<Integer, Integer>frequency)
	    {
	        if (left > right) {
	            return;
	        }
	        if (nums[left] == nums[right])
	        {
	            Integer count = frequency.get(nums[left]);
	            if (count == null) {
	                count = 0;
	            }
	            frequency.put(nums[left], count + (right - left + 1));
	            return;
	        }
       int mid = (left + right)/2;
	 
	        
	        findFrequency(nums, left, mid, frequency);
	        findFrequency(nums, mid + 1, right, frequency);
	    }
	 
	    public static void main(String[] args)
	    {
	        int[] nums = { 2, 2, 2, 4, 4, 4, 5, 5, 6, 8, 8, 9 };
	 
	       
	        Map<Integer, Integer> frequency = new HashMap<>();
	        findFrequency(nums, 0, nums.length - 1, frequency);
	 
	        System.out.println(frequency);
	    }
	}



