package com.Strings;

public class ManipulatingStrings {

	

			public static void main(String[] args) {
				
			//Predefined string in code is as "JAVA is Simple"
			String txt= "JAVA is Simple";
			//Converting into UpperCase
			System.out.println(txt.toUpperCase()); 
			
			
			//Converting into LowerCase
			System.out.println(txt.toLowerCase()); 
			
			//Converting into 1st words of letter
			String[] words=txt.split("\\s");	
			for(String w:words){  
				System.out.print(w.charAt(0)); 
				System.out.print(" ");
			}
			System.out.println(" ");
			
			// Converting into Change order
			String[] words1=txt.split("\\s");  
			for(String w:words1){  
				System.out.println(w); 
			}
			
			//Converting into String Builder reverse
			StringBuilder words2= new StringBuilder(" Simple is JAVA ");
			
			Object words21;
			System.out.println("String = " + words2.toString());
			StringBuilder reverseStr = words2.reverse();
			System.out.println("Reverse String = " + reverseStr.toString());
			
			//Total Length
			System.out.println("length of string " + txt.length());
		}
		}