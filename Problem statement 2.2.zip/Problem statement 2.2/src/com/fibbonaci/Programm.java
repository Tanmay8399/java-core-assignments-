package com.fibbonaci;
import java.util.Scanner;
public class Programm {

	

	

	    public static void main(String[] args) {

	        int count;
	        int number1 , number2 ;
	        System.out.println("How may numbers you want in the sequence:");
	        Scanner scanner = new Scanner(System.in);
	        count = scanner.nextInt();
	        System.out.println("Enter the two numberss  ");
	        number1=scanner.nextInt();
	        number2=scanner.nextInt();

	        System.out.print("Fibonacci Series of given numbers are as follows "+count+" numbers:");

	        int i=1;
	        while(i<=count)
	        {
	            System.out.print(number1+" ");
	            int sumOfPreviousTwo = number1 + number2;
	            number1 = number2;
	            number2 = sumOfPreviousTwo;
	            i++;
	        }
	    }
	}
