package com.BankAccounts;

public class BankAccount {

	
	    int accNo;
	    String custName;
	    String accType;
	    double balance;
	   
	    public int getaccNo() {
	        return accNo;
	    }
	   
	    public void setaccNo(int accNo) {
	        this.accNo = accNo;
	    }
	   
	    public String getName() {
	        return custName;
	    }
	   
	    public void setName(String custName) {
	        this.custName =custName;
	    }
	   
	    public String getaccType() {
	        return accType;
	    }
	   
	    public void setaccType(String accType) {
	        this.accType = accType;
	    }
	   
	    public double getBalance() {
	       
	        if( balance <1000)
	        {
	        try
	        {   
	            throw new NumberFormatException();
	        }
	        catch(NumberFormatException nw)
	        {
	            System.out.println("Balance is low"+balance);
	        }
	        }
	       
	       
	        return balance;
	       
	    }
	    public void setBalance(double balance) {
	        this.balance = balance;
	    }//end setter and getter

	    public BankAccount() {
	       
	        this.accNo = 2882;
	        this.custName = "Tanmay";
	        this.accType = "Saving";
	        this.balance = 400;
	    }
	   
	   
	   
	   
	    public BankAccount(int accNo, String custName, String accType,
	            double balance) {
	       
	        this.accNo = accNo;
	        this.custName =custName;
	        this.accType = accType;
	        this.balance = balance;
	    }
	    void deposit(double amt)
	    {
	        if(amt<0)
	        {
	            try
	            {
	                throw new NumberFormatException();
	            }
	            catch(NumberFormatException nf)
	            {
	                System.out.println("Negaive Amount cant be deposited");
	            }
	        }
	        else
	        {
	            balance=getBalance()+amt;
	            System.out.println("Current balance is ="+balance);
	           
	        }
	       
	       
	       
	    }
	     public void withdraw(double amt){
	         if(amt>1000)
	            {
	                try
	                {
	                    throw new NumberFormatException();
	                }
	                catch(NumberFormatException nf)
	                {
	                    System.out.println("Insufficient Funds ");
	                }
	            }
	            else
	            {
	                balance=getBalance()-amt;
	                System.out.println("Current balance is ="+balance);
	               
	            }
	       
	       
	       
	       
	       
	    }
	     void display()
	     {
	    System.out.println("Balance is ="+getBalance());   
	     }
	   
	   
	   
	   
	     public static void main(String[] args) {
	    	 BankAccount b=new BankAccount();
	         b.deposit(3000);
	         b.display();
	         b.withdraw(400);
	         b.display();
	         b.withdraw(2000);
	         b.getBalance();
	         b.display(); 
	       
	      
	       
	       
	    }
	   
	   
	   
	   
	}
